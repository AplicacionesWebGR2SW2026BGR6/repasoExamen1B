# práctica 2 — landing de faro idiomas

tienes 1 hora. vas a armar una landing de escritorio (1440 px de ancho) con html + css puro: sin javascript, sin media queries, sin frameworks y sin preprocesadores.

puedes partir de tu kit: copia `estilos.css` como `css/base.css` y cambia **solo** los valores de `:root` (colores, fuentes y, si hace falta, algún tamaño). el reset y los componentes se quedan. lo que sea propio de cada sección va en su `.css`. usa las clases del kit: `contenedor`, `seccion`, `seccion--alt`, `titulo-seccion`, `titulo-seccion__fina`, `titulo-seccion__gruesa`, `descripcion`, `btn`, `btn--primario`, `btn--contorno`, `btn--pildora`, `btn--grande`, `grilla`, `grilla--3`, `grilla--4`, `tarjeta`, `tarjeta__imagen`, `tarjeta__cuerpo`, `tarjeta__titulo`, `tarjeta__texto`, `campo__control`, `tabla`, `flex`, `flex--centro`, `flex--entre`, `flex--columna`, `texto-centro`, `texto-degradado` y `oculto-visual`.

el diseño de referencia es la captura `captura.png` de esta carpeta. no copies café bruma ni ik developers: esta es de una academia de idiomas, con otra paleta, otro hero y una tabla.

## qué debes entregar

una carpeta con `index.html` y un `css/` que tenga `base.css` y un `.css` por sección: `header.css`, `hero.css`, `cursos.css`, `horarios.css`, `cifras.css`, `boletin.css` y `footer.css`.

## secciones, en este orden

1. **header** — logo a la izquierda («faro»), menú al centro (inicio, cursos, horarios, cifras, contacto) y botón «inscribirme» a la derecha, en píldora.
2. **hero** — imagen a todo el ancho, con un velo oscuro y el texto centrado encima (no es el hero a dos columnas de la práctica 1). dos botones: «ver cursos» (sólido) y «ver horarios» (contorno).
3. **cursos** — cuadrícula de 3 tarjetas con caja visible (borde, sombra y padding en `tarjeta__cuerpo`). la del medio, «preparación ielts», lleva el modificador `tarjeta--destacada` (cuerpo en petrol, texto claro y una insignia «recomendado» sobre la foto).
4. **horarios** — una **tabla** de planes (grupal, intensivo, particular) con `caption`, `thead`, `tbody`, filas zebra y la columna del intensivo destacada.
5. **cifras** — una franja petrol con 4 números: 12 años, 1.800 estudiantes, 6 idiomas, 24 docentes.
6. **boletín** — un formulario corto, en una sola fila: input de correo + botón «suscribirme».
7. **footer** — marca y texto, enlaces, sede/horario/teléfono, redes, y debajo el copyright.

## paleta

- petrol / primario: `#0F4C5C`
- hover / secundario: `#155E75`
- teal de apoyo: `#0E7490`
- acento cian: `#22D3EE`
- degradado de «hablando» y de las cifras: `#A5F3FC` → `#22D3EE` (180deg)
- títulos: `#0B1F2A`
- texto: `#334155`
- texto suave: `#5B6E7A`
- texto sobre petrol (cifras y tarjeta destacada): `#B6D4DC`
- fondo frío: `#F4F8FA`
- fondo alt (hielo): `#E6F1F5`
- blanco: `#FFFFFF`
- borde: `#C9D6DC`
- velo del hero: `rgba(11, 31, 42, 0.62)`

horarios y el bloque superior del footer van sobre el fondo hielo; la franja de cifras va en petrol; el resto, sobre el fondo frío (salvo el hero, que es la foto).

## tipografía

- títulos, logo y números de cifra: [Fraunces](https://fonts.google.com/specimen/Fraunces) (400, 600, 700; el logo en itálica)
- el resto: [Figtree](https://fonts.google.com/specimen/Figtree) (300, 400, 500, 600, 700)
- cárgalas con un `<link>` de google fonts. font awesome va por cdnjs, para los iconos de redes del footer.

tamaños:

- logo: 24 px, itálica 700
- enlaces del menú: 16 px, peso 500
- título del hero: 48 px (400) y 64 px la línea gruesa (700)
- «hablando» va con el degradado recortado al texto (`background-clip: text`)
- títulos de sección: 36 px (primera línea 400, segunda 700), centrados, en fraunces
- descripciones e intro: 18 px
- cuerpo: 16 px
- textos chicos (botones de tarjeta, copyright, celdas): 14 px
- títulos de tarjeta: 20 px
- números de cifras: 56 px, con el mismo degradado de «hablando»
- caption de la tabla: 20 px, fraunces, peso 600

## medidas clave (escritorio, sin responsive)

- contenedor: **1200 px**, centrado. el contenido del header también va dentro de ese contenedor
- header: alto **80 px**, padding vertical **12 px**, sombra suave
- separación entre enlaces del menú: **32 px**
- botón del header: píldora, alto **40 px**
- hero: alto **560 px**, contenido como máximo **720 px**, velo encima de la foto
- descripción del hero: máximo **580 px**, margen **24 px** arriba y **40 px** abajo
- botones del hero: `btn--grande` (alto 56 px), con **16 px** de separación; el sólido usa el cian `#22D3EE` con texto oscuro; el de contorno es blanco
- cursos: padding de sección **96 px 0**, intro con **64 px** debajo, gap de la cuadrícula **32 px**, fotos de alto **200 px**
- insignia «recomendado»: arriba a la derecha de la tarjeta, **16 px** del borde, padding **4 px 12 px**, píldora, fondo cian
- el cuerpo de `tarjeta--destacada` va en `#0F4C5C`; el botón de esa tarjeta es una píldora blanca
- horarios: padding **96 px 0**, intro con **48 px** debajo; la tabla va en un marco blanco con padding **32 px**, radio **10 px** y borde
- la columna destacada usa un fondo `rgba(14, 116, 144, 0.12)` (un poco más fuerte en las filas zebra) y el precio del intensivo va en petrol, negrita
- cifras: padding **80 px 0**, 4 columnas, etiquetas en `#B6D4DC` con **8 px** sobre el número
- boletín: padding **96 px 0**; el form tiene un máximo de **560 px**, centrado, con **12 px** entre el input y el botón; el input estira (`flex: 1`) y mide **48 px** de alto
- footer: padding **60 px 0 80 px**; columnas aprox. **360 / 220 / 300 / resto**; iconos de red **34 × 34 px**, redondos, abajo a la derecha (`align-self` y `justify-self: end`)
- copyright: padding **16 px 0**
- unidades en rem (deja el equivalente en px en un comentario, ej. `5rem; /* 80px */`)

## imágenes (picsum, ids y tamaños fijos)

- hero: `https://picsum.photos/id/485/1440/720`
- cursos:
  - inglés conversacional: `https://picsum.photos/id/20/540/360`
  - preparación ielts: `https://picsum.photos/id/180/540/360`
  - portugués para viajar: `https://picsum.photos/id/177/540/360`

todas con `alt` descriptivo.

## textos

- logo: Faro
- hero: «el idioma se aprende **hablando**». descripción: «grupos pequeños, docentes nativos y una sede en teusaquillo. empieza el próximo lunes.»
- cursos: inglés conversacional, preparación ielts (destacada, insignia «recomendado»), portugués para viajar. inventa una línea de apoyo para cada una, o usa las de la captura
- tabla (caption: «horarios y tarifas del trimestre, marzo a mayo de 2026»):

  | detalle | grupal | intensivo | particular |
  | días | lunes, miércoles y viernes | lunes a viernes | a convenir |
  | horario | 18:00 a 20:00 | 9:00 a 12:00 | a convenir |
  | intensidad | 6 h / semana | 15 h / semana | 2 h / semana |
  | cupos | 8 a 12 personas | 6 a 8 personas | 1 persona |
  | precio / mes | $280.000 | $520.000 | $360.000 |

- cifras: 12 años en teusaquillo, 1.800 estudiantes al año, 6 idiomas para elegir, 24 docentes en sede
- boletín: «el calendario, en tu correo». «te avisamos cuando abren los grupos del próximo trimestre. sin spam, una vez al mes.»
- footer: carrera 19 # 39a-21, teusaquillo; lun–vie 7:00 a 20:00, sáb 8:00 a 13:00; teléfono +57 310 890 4567; copyright «© 2026 Faro Idiomas. todos los derechos reservados.»

## criterios que voy a mirar

- html semántico: `header`, `nav`, `main`, `section`, `footer`, `form`, `table` (con `caption`, `thead`, `tbody` y `th` con `scope`), y un `lang="es"`
- bem en español: `bloque__elemento--modificador` (ojo al `tarjeta--destacada` y al `tabla__columna--destacada`)
- flexbox y grid (el header y el boletín en flex; cursos, cifras y el footer en grid)
- los tres botones: sólido (`btn--primario`), contorno (`btn--contorno`) y píldora (`btn--pildora`)
- sin javascript, sin media queries
- la página se ve bien a 1440 px, como en la captura
