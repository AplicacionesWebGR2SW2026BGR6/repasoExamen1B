# práctica 3 — landing de estudio umbral

tienes 1 hora. vas a armar una landing de escritorio (1440 px de ancho) con html + css puro: sin javascript, sin media queries, sin frameworks y sin preprocesadores.

puedes partir de tu kit: copia `estilos.css` como `css/base.css` y cambia **solo** los valores de `:root` (colores, fuentes y, si hace falta, algún tamaño). el reset y los componentes se quedan. lo que sea propio de cada sección va en su `.css`. usa las clases del kit: `contenedor`, `seccion`, `seccion--alt`, `titulo-seccion`, `titulo-seccion__fina`, `titulo-seccion__gruesa`, `descripcion`, `btn`, `btn--primario`, `btn--contorno`, `btn--pildora`, `btn--grande`, `grilla`, `grilla--3`, `tarjeta`, `tarjeta__cuerpo`, `formulario`, `campo`, `campo--ancho`, `campo__etiqueta`, `campo__control`, `campo__control--area`, `tabla`, `flex`, `flex--centro`, `flex--entre`, `flex--columna`, `texto-centro`, `texto-degradado` y `oculto-visual`.

el diseño de referencia es la captura `captura.png` de esta carpeta. no copies café bruma ni faro idiomas: esta es de un estudio de arquitectura, con otra paleta, un hero a dos columnas, filas alternadas, una tabla con `tfoot`, testimonios, un faq con `details` y un formulario completo.

## qué debes entregar

una carpeta con `index.html` y un `css/` que tenga `base.css` y un `.css` por sección: `header.css`, `hero.css`, `proyectos.css`, `planes.css`, `voces.css`, `preguntas.css`, `contacto.css` y `footer.css`.

## secciones, en este orden

1. **header** — logo a la izquierda («umbral»), menú al centro (inicio, proyectos, planes, voces, contacto) y botón «agendar visita» a la derecha, en píldora.
2. **hero** — a dos columnas: texto a la izquierda e imagen a la derecha (no es el hero a todo el ancho de la práctica 2). una leyenda flotante sobre la foto, con `position: absolute`. dos botones: «ver proyectos» (sólido) y «agendar visita» (contorno).
3. **proyectos** — tres encargos en filas alternadas (zigzag): foto–texto, texto–foto, foto–texto. usa una cuadrícula de dos columnas y un modificador `proyecto--invertido` (con `order`) en la fila del medio. la primera tarjeta lleva una insignia «entregado 2025» sobre la foto.
4. **planes** — una **tabla** de honorarios (consulta, anteproyecto, proyecto ejecutivo) con `caption`, `thead`, `tbody`, `tfoot`, filas zebra y la columna del anteproyecto destacada.
5. **voces** — tres testimonios en tarjeta, cada uno con un retrato circular (`border-radius: 50%`) y una comilla decorativa.
6. **preguntas** — un faq con `details` y `summary` (sin javascript). la primera pregunta va abierta (`open`).
7. **contacto** — un formulario completo en la grilla de dos columnas (`.formulario`): texto, email, teléfono, select, radios, textarea, checkbox y el botón de envío.
8. **footer** — marca y texto, enlaces, dirección/horario/teléfono, redes, y debajo el copyright.

## paleta

- índigo / primario: `#2C2A4A`
- hover / secundario: `#3D3A63`
- acento oro: `#C9A36B`
- degradado de «umbral»: `#E8C990` → `#C9A36B` (180deg)
- títulos: `#1B1730`
- texto: `#3F3C4F`
- texto suave: `#6E6A7A`
- fondo piedra: `#F6F3EE`
- fondo alt (lila suave): `#EBE6F0`
- blanco: `#FFFFFF`
- borde: `#D6D1C8`
- columna destacada de la tabla: `rgba(201, 163, 107, 0.16)` (un poco más fuerte en las filas zebra: `0.28`)

planes, preguntas y el bloque superior del footer van sobre el lila suave; el resto, sobre el fondo piedra (salvo las tarjetas y los marcos, que van en blanco).

## tipografía

- títulos, logo y caption de la tabla: [Bodoni Moda](https://fonts.google.com/specimen/Bodoni+Moda) (400, 600, 700; el logo en itálica)
- el resto: [Outfit](https://fonts.google.com/specimen/Outfit) (300, 400, 500, 600, 700)
- cárgalas con un `<link>` de google fonts. font awesome va por cdnjs, para los iconos de redes del footer.

tamaños:

- logo: 24 px, itálica 700
- enlaces del menú: 16 px, peso 500
- etiqueta del hero («estudio de arquitectura»): 14 px, peso 600, mayúsculas, letter-spacing amplio, en oro
- título del hero: 48 px (400) y 64 px la línea gruesa (700)
- «umbral» va con el degradado recortado al texto (`background-clip: text`)
- títulos de sección: 36 px (primera línea 400, segunda 700), centrados, en bodoni moda
- descripciones e intro: 18 px
- cuerpo: 16 px
- textos chicos (insignia, copyright, celdas, metadatos): 14 px; la insignia y el pie de la tabla, 12 px
- títulos de proyecto: 36 px
- nombres en los testimonios y preguntas del faq: 20 px
- caption de la tabla: 20 px, bodoni moda, peso 600
- números de honorarios del anteproyecto: peso 700, color índigo

## medidas clave (escritorio, sin responsive)

- contenedor: **1200 px**, centrado. el contenido del header también va dentro de ese contenedor
- header: alto **80 px**, padding vertical **12 px**, sombra suave
- separación entre enlaces del menú: **32 px**
- botón del header: píldora, alto **40 px**
- hero: padding **64 px 0**; cuadrícula de dos columnas (texto **520 px**, imagen el resto), gap **80 px**, imagen de alto **560 px**, radio **10 px**
- descripción del hero: máximo **460 px**, margen **24 px** arriba y **40 px** abajo
- botones del hero: `btn--grande` (alto 56 px), con **16 px** de separación
- leyenda de la foto: abajo a la izquierda, **24 px** del borde, padding **12 px 16 px**, fondo blanco, radio **6 px** y sombra
- proyectos: padding de sección **96 px 0**, intro con **80 px** debajo, **80 px** entre filas y **80 px** entre foto y texto; fotos de alto **400 px**, radio **10 px**
- insignia «entregado 2025»: arriba a la izquierda de la foto, **16 px** del borde, padding **4 px 12 px**, píldora, fondo oro y texto oscuro
- el tipo de encargo (vivienda, interiorismo, local) va en mayúsculas y oro; el «m²» no se pone en mayúsculas
- planes: padding **96 px 0**, intro con **48 px** debajo; la tabla va en un marco blanco con padding **32 px**, radio **10 px** y borde
- el precio del anteproyecto va en índigo, negrita
- el `tfoot` es una sola celda (`colspan="4"`), en itálica, 12 px, alineada a la izquierda
- voces: padding **96 px 0**, intro con **64 px** debajo; retratos **72 × 72 px**, redondos, con borde oro de **2 px**; comilla decorativa arriba a la izquierda de la tarjeta (`position: absolute`)
- preguntas: padding **96 px 0**, intro con **48 px** debajo; la lista mide como máximo **800 px**, centrada, en un marco blanco; el `summary` es un flex con un «+» a la derecha que pasa a «–» cuando el `details` está abierto (`details[open]`)
- contacto: padding **96 px 0**, intro con **48 px** debajo; el form tiene un máximo de **800 px**, centrado, con padding **40 px**, radio **10 px** y borde; radios y el checkbox en una fila, con **8 px** entre el control y su texto; el botón no se estira a todo el ancho (`align-self: start`)
- footer: padding **60 px 0 80 px**; columnas aprox. **360 / 220 / 300 / resto**; iconos de red **34 × 34 px**, redondos, abajo a la derecha (`align-self` y `justify-self: end`)
- copyright: padding **16 px 0**
- unidades en rem (deja el equivalente en px en un comentario, ej. `5rem; /* 80px */`)

## imágenes (picsum, ids y tamaños fijos)

- hero: `https://picsum.photos/id/153/640/560`
- proyectos:
  - casa farallones: `https://picsum.photos/id/206/640/480`
  - apartamento san felipe: `https://picsum.photos/id/42/640/480`
  - taller roma: `https://picsum.photos/id/192/640/480`
- retratos de voces:
  - maría isabel restrepo: `https://picsum.photos/id/1027/160/160`
  - laura herrera: `https://picsum.photos/id/823/160/160`
  - daniela lópez: `https://picsum.photos/id/836/160/160`

todas con `alt` descriptivo.

## textos

- logo: Umbral
- hero: «el estudio de arquitectura». título: «la casa empieza **en el umbral**». descripción: «arquitectura e interiores en quinta camacho. vivienda, reforma y espacio de trabajo, del anteproyecto a la obra.» leyenda de la foto: «casa farallones · la calera · 2025»
- proyectos:
  - casa farallones — vivienda · 280 m². «la calera, sobre la pendiente. la casa se abre al cerro y se cierra al viento. un patio interior ordena la vida del día.» dato: «anteproyecto y obra, 14 meses». insignia: «entregado 2025»
  - apartamento san felipe — interiorismo · 92 m². «se unieron cocina y estar, se ganó luz y un comedor que sí se usa. la reforma no tocó la estructura, sí la forma de habitar.» dato: «reforma, 5 meses»
  - taller roma — local · 140 m². «un depósito en teusaquillo convertido en taller y sala de reuniones. el ventanal se dejó a la vista; el resto se ordenó alrededor de la luz.» dato: «proyecto y obra, 8 meses»
- tabla (caption: «honorarios de diseño, vigencia 2026»):

  | detalle | consulta | anteproyecto | proyecto ejecutivo |
  | alcance | una sesión de 90 minutos en el lote o en el estudio | distribución, volumetría y una primera estimación de obra | planos para licencia y construcción, detalles y memorias |
  | duración | 1 sesión | 6 a 8 semanas | 4 a 6 meses |
  | entregables | acta y recomendaciones | plantas, cortes, fachadas y presupuesto preliminar | expediente completo para curaduría y obra |
  | revisiones | — | 2 rondas | 3 rondas |
  | visitas | 1 visita al predio | 2 visitas | 4 visitas de seguimiento |
  | honorarios | $350.000 | $8.400.000 | $18.600.000 |

  pie (`tfoot`): «los valores no incluyen licencias, estudios de suelos ni dirección de obra. vigencia de enero a diciembre de 2026.»

- voces:
  - maría isabel restrepo, casa farallones: «entendieron el lote antes de dibujar una línea. la casa mira el cerro y no se pelea con él.»
  - laura herrera, apartamento san felipe: «ganamos luz y una cocina que sí usamos. el proceso fue claro, sin sorpresas en la obra.»
  - daniela lópez, taller roma: «el local era un depósito. ahora es el taller donde recibimos clientes, y se nota.»
- preguntas:
  - ¿en qué zonas de bogotá trabajan? — principalmente chapinero, teusaquillo, usaquén y la calera. otros encargos los evaluamos en la consulta, según el lote y el calendario del estudio.
  - ¿cuánto tarda un anteproyecto? — entre 6 y 8 semanas, según el tamaño del predio y el número de revisiones. las dos rondas incluidas suelen alcanzar para cerrar la distribución.
  - ¿hacen dirección de obra? — sí, como un servicio aparte. no está incluida en el honorario del proyecto ejecutivo; si te interesa, la cotizamos después de tener el expediente.
  - ¿trabajan reformas de apartamento? — sí, es buena parte de lo que hacemos. el alcance lo definimos en la consulta: a veces basta con redistribuir, a veces hay que tocar instalaciones.
  - ¿la consulta se abona al proyecto? — sí, si firmamos el anteproyecto en los tres meses siguientes. si no seguimos, el valor de la sesión queda como honorario de esa visita.
- contacto: «cuéntanos el encargo». «déjanos los datos del predio y te respondemos en dos días hábiles para agendar la visita.»
  - campos: nombre (texto), correo (email), teléfono (tel), tipo de encargo (select: consulta, anteproyecto, reforma, interiorismo, otro), tipo de inmueble (radio: vivienda, local, oficina; vivienda va marcado), mensaje (textarea), checkbox «acepto que me contacten por correo o whatsapp»
  - botón: «enviar mensaje». cada control va con su `label` (o un `p` de etiqueta en el grupo de radios). el form usa `method="post"` y `action="index.html"`
- footer: calle 70a # 11-20, quinta camacho; lun–vie 9:00 a 18:00; teléfono +57 312 456 0180; copyright «© 2026 Estudio Umbral. todos los derechos reservados.»

## criterios que voy a mirar

- html semántico: `header`, `nav`, `main`, `section`, `footer`, `form`, `table` (con `caption`, `thead`, `tbody`, `tfoot` y `th` con `scope`), `details`/`summary`, y un `lang="es"`
- bem en español: `bloque__elemento--modificador` (ojo al `proyecto--invertido`)
- flexbox y grid (el header en flex; el hero, los proyectos, las voces y el formulario en grid)
- `position: relative` + `absolute` al menos en la leyenda del hero y en la insignia de proyectos
- los tres botones: sólido (`btn--primario`), contorno (`btn--contorno`) y píldora (`btn--pildora`)
- sin javascript, sin media queries
- la página se ve bien a 1440 px, como en la captura
