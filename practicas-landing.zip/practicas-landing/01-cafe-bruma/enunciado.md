# práctica 1 — landing de café bruma

tienes 1 hora. vas a armar una landing de escritorio (1440 px de ancho) con html + css puro: sin javascript, sin media queries, sin frameworks y sin preprocesadores. puedes llegar con un `.css` ya preparado (por ejemplo tu `base.css` con variables y reset).

el diseño de referencia es la captura `captura.png` de esta carpeta. no copies la landing de ik developers: esta es de un café de especialidad, con otra paleta y otras secciones.

## qué debes entregar

una carpeta con `index.html` y un `css/` que tenga `base.css` (variables en `:root` + reset) y un `.css` por sección: `header.css`, `hero.css`, `especialidades.css`, `metodo.css`, `reserva.css` y `footer.css`.

## secciones, en este orden

1. **header** — logo a la izquierda («café bruma»), menú al centro (inicio, carta, método, reserva, horario) y botón «reservar mesa» a la derecha.
2. **hero** — título y botón a la izquierda, imagen a la derecha.
3. **especialidades** — cuadrícula de 4 tarjetas con foto, nombre y una línea de texto.
4. **método** — 4 pasos en una fila: selección, tueste, descanso y preparación.
5. **reserva** — imagen a la izquierda y un formulario simple a la derecha.
6. **footer** — marca y texto, enlaces, horario/contacto, redes, y debajo el copyright.

## paleta

- marca / terracota: `#9C3B1E`
- botón verde bosque: `#2E5A3C`
- degradado de «bueno»: `#C45C26` → `#9C3B1E` (180deg)
- degradado de «despacio»: `#C4A265` → `#2E5A3C` (225deg)
- degradado del botón del header: `#C45C26` → `#6B2A14` (225deg)
- títulos: `#1F140E`
- texto de apoyo: `#6B5344`
- texto del footer: `#4A3B32`
- texto de tarjetas: `#2C241C`
- fondo crema: `#FFFBF5`
- fondo arena: `#F4EDE3`
- blanco: `#FFFFFF`
- borde de tarjetas e inputs: `#E8D9C8`

método y el bloque superior del footer van sobre el fondo arena; el resto, sobre el crema.

## tipografía

- títulos, logo y números de paso: [Cormorant Garamond](https://fonts.google.com/specimen/Cormorant+Garamond) (400, 600, 700; el logo en itálica)
- el resto: [Source Sans 3](https://fonts.google.com/specimen/Source+Sans+3) (300, 400, 500, 600, 700)
- cárgalas con un `<link>` de google fonts. font awesome es opcional (en el footer hay iconos de redes).

tamaños:

- logo: 24 px
- enlaces del menú: 16 px, peso 500
- título del hero: 48 px (300) y 56 px la línea gruesa (700)
- títulos de sección: 36 px (primera línea 400, segunda 700), centrados, en cormorant
- descripción del hero e intro del form: 18 px, interlineado 2
- cuerpo: 16 px
- textos chicos (botones, ayudas, copyright): 14 px
- títulos de tarjeta y de cada paso: 20 px
- números del método: 56 px, con el degradado de «bueno» recortado al texto

## medidas clave (escritorio, sin responsive)

- contenedor: **1200 px**, centrado. el contenido del header también va dentro de ese contenedor
- header: alto **80 px**, padding vertical **12 px**, sombra suave
- separación entre enlaces del menú: **32 px**
- botón del header: **152 × 40 px**, radio **6 px**
- hero: alto **520 px**, margen vertical **64 px**, separación texto–imagen **80 px**
- bloque de texto del hero: **520 px** de ancho; imagen **600 × 520 px**, radio **10 px**
- botón del hero: **180 × 52 px**, fondo `#2E5A3C`, con sombra
- especialidades: padding **88 px 0 100 px**, gap de la cuadrícula **40 px**, fotos de alto **180 px**, radio **10 px**
- método: padding **88 px 0 100 px**, gap **32 px**
- reserva: padding **88 px 0 100 px**, foto **480 × 520 px**, gap **80 px**; campos en dos columnas con gap **24 px**; inputs alto **48 px**, textarea **120 px**, padding interno **12 px 16 px**, radio **6 px**
- botón de enviar reserva: **200 × 52 px**, mismo verde del hero
- footer: padding **60 px 0 80 px**; columnas aprox. **360 / 220 / 300 / resto**; iconos de red **34 × 34 px**, redondos
- unidades en rem (deja el equivalente en px en un comentario, ej. `5rem; /* 80px */`)

## imágenes (picsum, ids y tamaños fijos)

- hero: `https://picsum.photos/id/431/600/520`
- especialidades:
  - espresso: `https://picsum.photos/id/63/540/360`
  - v60: `https://picsum.photos/id/1060/540/360`
  - pastelería: `https://picsum.photos/id/835/540/360`
  - tueste: `https://picsum.photos/id/766/540/360`
- reserva: `https://picsum.photos/id/513/480/520`

todas con `alt` descriptivo.

## textos

- logo: Café Bruma
- hero: «el café **bueno** se tuesta **despacio**». «bueno» y «despacio» van con los degradados recortados al texto (`background-clip: text`). descripción: «granos de origen, tueste lento y una mesa para quedarte un rato. en chapinero, bogotá.» botón: «ver la carta»
- especialidades: espresso de origen, filtrado v60, pastelería del día, tueste de la casa (inventa una línea de apoyo para cada una)
- método: 01 selección, 02 tueste, 03 descanso, 04 preparación (una o dos líneas por paso)
- reserva: nombre, correo, fecha, hora, personas y un comentario; botón «enviar reserva». cada input va con su `label`
- footer: horario (lun–vie 8:00 a 18:00, sáb 9:00 a 17:00), teléfono +57 310 456 7890, y copyright «© 2026 Café Bruma. todos los derechos reservados.»

## criterios que voy a mirar

- html semántico: `header`, `nav`, `main`, `section`, `footer`, `form`, y un `lang="es"`
- bem en español: `bloque__elemento--modificador`
- flexbox y grid (el header y el hero en flex; especialidades, método y los campos del form en grid)
- sin javascript, sin media queries
- la página se ve bien a 1440 px, como en la captura
